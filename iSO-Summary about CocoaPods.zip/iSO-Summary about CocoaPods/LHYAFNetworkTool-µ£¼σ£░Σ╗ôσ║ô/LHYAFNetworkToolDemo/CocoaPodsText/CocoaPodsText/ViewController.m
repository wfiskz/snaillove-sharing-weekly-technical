//
//  ViewController.m
//  CocoaPodsText
//
//  Created by 李宏远 on 16/3/28.
//  Copyright © 2016年 李宏远. All rights reserved.
//

#import "ViewController.h"
#import "MBProgressHUD.h"
#import "LhyAFNetworkTool.h"


@interface ViewController ()

@property(nonatomic, strong)MBProgressHUD *loading;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
  
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    btn.frame = CGRectMake(120, 300, 120, 40);
    [btn addTarget:self action:@selector(handleData) forControlEvents:UIControlEventTouchUpInside];
    [btn setTitle:@"开始解析" forState:UIControlStateNormal];
    btn.backgroundColor = [UIColor colorWithRed:0.162 green:0.100 blue:0.052 alpha:1.000];
    [self.view addSubview:btn];
    
    
}

- (void)handleData {
    
    

    [LhyAFNetworkTool getUrl:@"http://c.m.163.com/nc/article/headline/T1348647853363/0-140.html" body:nil response:LhyJSON requestHeadFile:nil success:^(NSURLSessionDataTask *task, id responseObject) {
        
     //   NSMutableArray *arr = [responseObject objectForKey:@"T1348647853363"];
     //   NSDictionary *dic = [arr firstObject];
     //   NSMutableArray *arrM = [dic objectForKey:@"ads"];
        
        NSLog(@"%@", responseObject);
        
    } failure:^(NSURLSessionDataTask *task, NSError *error) {
        
        /* 无网络状时 */
        NSLog(@"%@", error);
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"提示" message:@"网络无连接,当前为缓存内容" preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction *action = [UIAlertAction actionWithTitle:@"好的" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            
            
        }];
        [alert addAction:action];
        [self presentViewController:alert animated:YES completion:^{
            
        }];
        
        
    }];
    
}






- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
